import pika
import sys

connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='task_queue', durable=True)
count = 0 
message = ' '.join(sys.argv[1:]) or "Hello World!"
for i in range(30):
    channel.basic_publish(exchange='',
                          routing_key='task_queue',
                          body=message+str(count),
                          properties=pika.BasicProperties(
                             delivery_mode = 2, # make message persistent
                          ))
    count += 1
    print(" [x] Sent %r" % message)
connection.close()